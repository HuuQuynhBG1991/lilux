#!/bin/bash
echo "Replace YOUR_ADDRESS, YOUR_NODE:YOUR_PORT to run the miner"
while :; do
    ./astrominer -w dero1qy46v3tccnuxe9sxhzpe5klksfh5fz272uwylzrkgshc4acknp3lcqqaavnvj -r 192.168.16.106:10100 -r1 community-pools.mysrv.cloud:10300 -r2 dero.friendspool.club:10300 -p rpc;
    sleep 5;
done